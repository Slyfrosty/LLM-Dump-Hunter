
import re

filename = input("Enter path to .txt or .json file: ")

with open(filename, "r", encoding="utf-8", errors="ignore") as f:
    content = f.read()

print("\n[*] Scanning for secrets in", filename)

patterns = {
    "Email Addresses": r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+",
    "Ethereum Wallet Mnemonics (12 words)": r"(?:\b[a-z]+\b[\s\n]*){12}",
    "Private Keys": r"-----BEGIN (RSA|EC|DSA|PGP) PRIVATE KEY-----[\s\S]+?-----END \1 PRIVATE KEY-----",
    "Base64 Strings": r"[A-Za-z0-9+/=]{40,}",
    "JWT Tokens": r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.?[A-Za-z0-9_-]*",
    "API Keys": r"(sk_live|sk_test|AIza|ghp|AKIA|EAACEdEose0c|xox[baprs]-[a-zA-Z0-9]+)",
    ".env Entries": r"(APP_KEY|DB_PASSWORD|API_KEY|SECRET_KEY|ACCESS_TOKEN|MAIL_PASSWORD)=.+",
}

results = {}
for label, pattern in patterns.items():
    found = re.findall(pattern, content)
    results[label] = list(set(found))

for label, matches in results.items():
    print(f"\n=== {label} ===")
    if matches:
        for match in matches[:10]:
            print("  ", match[:100].replace("\n", " "))
        if len(matches) > 10:
            print(f"  [+] ...and {len(matches)-10} more")
    else:
        print("  [None found]")

print("\n[*] Scan complete.")
